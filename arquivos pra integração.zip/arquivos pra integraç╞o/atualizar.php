<?php

$nome = $_POST["nome"];
$tel = $_POST["tel"];
$email = $_POST["email"];
$id = $_POST["id"];

include_once'conexao.php';

$sql = "update ralemagi set nome = '".$nome."', tel = '".$tel."', email = '".$email."' where id =".$id;

if(mysqli_query($con,$sql)){
	$msg="Editado com sucesso";
	}else{
		$msg="Erro ao editar";
	}
	
	mysqli_close($con);
	
	echo"<script>alert('".$msg."'); location.href='index.php';</script>";

?>