<?php 

$id =$_GET["id"];

include_once'conexao.php';

$sql ="delete from ralemagi where id =".$id;

if(mysqli_query($con,$sql)){
	$msg="Excluido com sucesso";
	}else{
		$msg="Erro ao excluir";
	}
	
	mysqli_close($con);
	
	echo"<script>alert('".$msg."'); location.href='index.php';</script>";


?>