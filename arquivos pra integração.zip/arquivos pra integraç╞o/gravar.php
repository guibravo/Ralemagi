<?php

$nome = $_POST["nome"];
$telefone = $_POST["telefone"];
$email = $_POST["email"];
include_once 'conexao.php';

$sql = "insert into cliente values(null,'".$nome."','".$telefone."','".$email."')";

if(mysqli_query($con,$sql)){
	$msg="Cadastrado com sucesso";
	}else{
		$msg="Erro ao gravar";
	}
	
	mysqli_close($con);
	
	echo"<script>alert('".$msg."'); location.href='index.php';</script>";
?>

