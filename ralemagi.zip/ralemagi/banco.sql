create database ralemagi;

use ralemagi;

create table cliente(
	idcliente int primary key auto_increment,
	nome varchar(40) not null,
	email varchar(45) not null,
	telefone varchar(9) not null
	);
	
	insert into cliente values
	(null,'guilherme','guilherme@gmail.com','999999999');
	insert into cliente values 
	(null,'guilherme1','guilherme1@gmail.com','199999999');
	
create table produto(
	idproduto int primary key auto_increment,
	nome varchar(40) not null,
	preço varchar(9) not null
	);
	
	insert into produto values
	(null,'biscoito','3,90');
	insert into produto values 
	(null,'bolinho','5,00');