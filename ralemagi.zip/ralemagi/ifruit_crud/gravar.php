<?php

$nome = $_POST["nome"];
$endereco = $_POST["endereco"];
$cidade = $_POST["cidade"];
$uf = $_POST["uf"];
$cep = $_POST["cep"];
$cnpj = $_POST["cnpj"];
$fax = $_POST["fax"];
$tel = $_POST["tel"];
$site = $_POST["site"];
$email = $_POST["email"];
include_once 'conexao.php';

$sql = "insert into ifruit_db values(null,'".$nome."','".$endereco."','".$cidade."','".$uf."','".$cep."','".$cnpj."','".$fax."','".$tel."','".$site."','".$email."')";

if(mysqli_query($con,$sql)){
	$msg="Cadastrado com sucesso";
	}else{
		$msg="Erro ao gravar";
	}
	
	mysqli_close($con);
	
	echo"<script>alert('".$msg."'); location.href='index.php';</script>";
?>

