<html class="no-js" lang="pt-br"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>iFruit</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
        <link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="assets/css/style.css"/>
        <link rel="stylesheet" href="assets/css/responsive.css"/>
    </head>
    
    <body>
        <header id="home" class="navbar-fixed-top">
            <div class="main_menu_bg">
                <div class="container"> 
                    <div class="row">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid">                            
                                <div class="navbar-header">
                                    <a class="navbar-brand our_logo" href="#"><img src="assets/images/logo.png" alt="" /></a>
                                </div>
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul class="nav navbar-nav navbar-right">                                        
                                        <li><a href="cadastro.php"><strong>Cadastro</strong></a></li>
                                        <li><a href="consulta.php"><strong>Consulta</strong></a></li>                                        
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>	
        </header> 

        <section id="slider" class="slider">            
                <div class="container">
                    <div class="row">
                        <div class="main_slider text-center">
                            <div class="col-md-12">
                                <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                                    <h1>Quitanda Digital</h1>
                                    <p></p>
                                    <button href="" class="btn-lg">Confira</button>
                                </div>
                            </div>	
                        </div>

                    </div>
                </div>

        <footer class="footer footer_style">
            <div class="container text-center">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="copyright">
							<p><strong>Feito com <i class="fa fa-heart"></i> pela <a>Turminha do Barulho</a>2018. Nenhum direito reservado.</strong></p>

						</div>
                    </div>
                </div>
            </div>
        </footer>

		</section>

    </body>
</html>
