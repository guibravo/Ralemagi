
(function ($) {
    "use strict";


    /*==================================================================
    [ Validate after type ]*/
    $('.validate-input .input100').each(function(){
        $(this).on('blur', function(){
            if(validate(this) == false){
                showValidate(this);
            }
            else {
                $(this).parent().addClass('true-validate');
            }
        })    
    })
  
  
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
        var check = true;

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
            }
        }

        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
           $(this).parent().removeClass('true-validate');
        });
    });

     function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i) == null) {
                return false;
            }
        }
		 if($(input).attr('name') == 'nome') {
            if($(input).val().trim().match(/^[a-zA-Z ]{2,30}$/) == null) {
                return false;
            }
        }
		if($(input).attr('name') == 'cidade') {
            if($(input).val().trim().match(/^[a-zA-Z ]{2,30}$/) == null) {
                return false;
            }
        }
		if($(input).attr('name') == 'cep') {
            if($(input).val().trim().match(/^[0-9]{2}.[0-9]{3}-[0-9]{3}$/) == null) {
                return false;
            }
        }
		if($(input).attr('name') == 'cnpj') {
            if($(input).val().trim().match(/^\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}$/) == null) {
                return false;
            }
        }
		if($(input).attr('name') == 'telefone') {
            if($(input).val().trim().match(/^(?:\+)[0-9]{2}\s?(?:\()[0-9]{2}(?:\))\s?[0-9]{4,5}(?:-)[0-9]{4}$/) == null) {
                return false;
            }
        }
		
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }
	

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');

        $(thisAlert).append('<span class="btn-hide-validate">&#xf136;</span>')
        $('.btn-hide-validate').each(function(){
            $(this).on('click',function(){
               hideValidate(this);
            });
        });
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();
        $(thisAlert).removeClass('alert-validate');
        $(thisAlert).find('.btn-hide-validate').remove();
    }
    
    

})(jQuery);