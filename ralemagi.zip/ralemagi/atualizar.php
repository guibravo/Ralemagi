<?php

$nome = $_POST["nome"];
$endereco = $_POST["endereco"];
$cidade = $_POST["cidade"];
$uf = $_POST["uf"];
$cep = $_POST["cep"];
$cnpj = $_POST["cnpj"];
$fax = $_POST["fax"];
$tel = $_POST["tel"];
$site = $_POST["site"];
$email = $_POST["email"];
$id = $_POST["id"];

include_once'conexao.php';

$sql = "update ifruit_db set nome = '".$nome."', endereco = '".$endereco."', cidade = '".$cidade."', uf = '".$uf."', cep = '".$cep."', cnpj = '".$cnpj."', tel = '".$tel."', fax = '".$fax."', site = '".$site."', email = '".$email."' where id =".$id;

if(mysqli_query($con,$sql)){
	$msg="Editado com sucesso";
	}else{
		$msg="Erro ao editar";
	}
	
	mysqli_close($con);
	
	echo"<script>alert('".$msg."'); location.href='index.php';</script>";

?>